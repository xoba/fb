# A tiny archive

Original synthetic files for the fb archive browser.

Open `data/colors.csv` to browse a table.
